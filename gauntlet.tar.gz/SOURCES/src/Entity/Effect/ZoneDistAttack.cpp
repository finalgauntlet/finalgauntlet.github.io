//
// Created by mymy on 12/06/17.
//

#include "Entity/Effect/ZoneDistAttack.hpp"

Gauntlet::ZoneDistAttack::ZoneDistAttack(int id)
	: Attack(id, "darkBall.mesh")
{

}