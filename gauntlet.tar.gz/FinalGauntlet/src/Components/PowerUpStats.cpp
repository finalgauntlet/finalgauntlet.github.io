//
// Created by mymy on 03/06/17.
//

#include "Components/PowerUpStats.hpp"

Gauntlet::PowerUpStats::PowerUpStats(Type const &type, double amount) :
	type(type), amount(amount)
{

}
