//
// Created by puentes on 22/05/17.
//

#include "Components/EntityState.hpp"

Gauntlet::State::State()
	: type(State::Type::DEFAULT)
{
}
