//
// Created by puentes on 06/06/17.
//

#include "Entity/Effect/CaCAttack.hpp"

Gauntlet::CaCAttack::CaCAttack(int id)
	: Attack(id, "empty.mesh")
{

}
