//
// Created by mymy on 13/06/17.
//

#ifndef INDIE_MINIBOSS_HPP
#define INDIE_MINIBOSS_HPP

#include "Entity/Entity.hpp"

namespace Gauntlet
{
  class MiniBoss : public Entity
  {
   public:
    MiniBoss(int id);
    ~MiniBoss() {};
  };
}


#endif //INDIE_MINIBOSS_HPP
