//
// Created by puentes on 06/06/17.
//

#ifndef INDIE_CACATTACK_HPP
#define INDIE_CACATTACK_HPP

#include "Entity/Effect/Attack.hpp"

namespace Gauntlet
{
  class CaCAttack : public Attack
  {
   public:
    CaCAttack(int id);

    virtual ~CaCAttack()
    {

    };
  };
}

#endif //INDIE_CACATTACK_HPP
