ogre_build
Repository for building OGRE v1.9 on Travis CI
