c++ Gauntlet-like made during the 2nd year at Epitech Paris in 6 weeks
Authors : Aragon My-Lan, Cholet Myriam, Puentes Timothée, Réchou Benjamin, Nakache Vincent and Benoît Linsey


Install:

	cd Install
	./install_indie

	NB : If your distribution doesn't use apt as package manager, feel free to replace it by yours

dependancies :

- ogre
- bullet
- cegui
- sfml
