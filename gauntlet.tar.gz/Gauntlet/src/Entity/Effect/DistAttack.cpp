//
// Created by puentes on 06/06/17.
//

#include "Entity/Effect/DistAttack.hpp"

Gauntlet::DistAttack::DistAttack(int id)
	: Attack(id, "R_knife.mesh")
{
}
